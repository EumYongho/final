export class AuthVO {
    private userID : string;
}